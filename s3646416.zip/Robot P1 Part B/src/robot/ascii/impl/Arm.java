package robot.ascii.impl;

import com.googlecode.lanterna.TextColor;
import com.googlecode.lanterna.terminal.swing.SwingTerminalFrame;

import control.RobotControl;
import robot.RobotMovement;

public class Arm implements RobotMovement, Drawable {
    private int height = 0;
    private int width = 0;
    private int depth = 0;
    private AbstractItem block = null;

    public Arm(int height, int width, int depth, Block block) {
        this.height = height;
        this.depth = depth;
        this.width = width;
        this.block = block;
    }

    public AbstractItem getBlock() {
        return this.block;
    }

    public void setBlock(AbstractItem block) {
        this.block = block;
    }

    public int getDepth() {
        return this.depth;
    }

    public int getWidth() {
        return this.width;
    }

    @Override
    public void draw(SwingTerminalFrame terminalFrame) {
        int maxRow = terminalFrame.getTerminalSize().getRows() - 1;
        int maxCol = terminalFrame.getTerminalSize().getColumns() - 1;

        // set arm colours
        terminalFrame.setForegroundColor(TextColor.ANSI.BLACK);
        terminalFrame.setBackgroundColor(TextColor.ANSI.WHITE);

        // NOTE: we translate to terminal co-ordinates where 0,0 is top left!

        // sets height of arm1
        for (int i = 0; i < this.height; i++) {
            terminalFrame.setCursorPosition(0, maxRow - i);
            terminalFrame.putCharacter(' ');
        }
        // sets width of arm 2
        for (int i = 0; i < this.width; i++) {
            terminalFrame.setCursorPosition(i + 1, maxRow - this.height + 1);
            terminalFrame.putCharacter(' ');
        }

        // sets depth of arm 3
        for (int i = 0; i < this.depth; i++) {
            terminalFrame.setCursorPosition(this.width, maxRow - this.height + 2 + i);
            terminalFrame.putCharacter(' ');
        }

    }

    @Override
    public void pick() {

    }

    @Override
    public void drop() {

    }

    @Override
    public void up() {
        this.height++;
    }

    @Override
    public void down() {
        this.height--;
    }

    @Override
    public void contract() {
        this.width--;
    }

    @Override
    public void extend() {
        this.width++;
    }

    @Override
    public void lower() {
        this.depth++;
    }

    @Override
    public void raise() {
        this.depth--;
    }
}
