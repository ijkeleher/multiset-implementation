package robot.ascii.impl;

import com.googlecode.lanterna.TextColor;
import com.googlecode.lanterna.terminal.swing.SwingTerminalFrame;
import robot.ascii.impl.AbstractItem;

public class Bar extends AbstractItem implements Drawable {

    private int height;
    private int position;

    public Bar(int height, int position) {

        super(height, position);

    }
}
