package robot.ascii.impl;

import com.googlecode.lanterna.TextColor;
import com.googlecode.lanterna.terminal.swing.SwingTerminalFrame;

public abstract class AbstractItem implements Drawable {

    private int height;
    private int position;

    public AbstractItem(int height, int position) {
        this.position = position;
        this.height = height;
    }

    public int getHeight() {
        return height;
    }

    public int getPosition() {
        return position;
    }

    public void setPosition(int position) {
        this.position = position;
    }

    @Override
    public void draw(SwingTerminalFrame terminalFrame) {
        int maxRow = terminalFrame.getTerminalSize().getRows() - 1;
        int maxCol = terminalFrame.getTerminalSize().getColumns() - 1;

        terminalFrame.setForegroundColor(TextColor.ANSI.BLACK);
        terminalFrame.setBackgroundColor(TextColor.ANSI.GREEN);

        // draw a 'bar' of height "draw_height" in middle column
        // NOTE: we translate to terminal co-ordinates where 0,0 is top left!
        int count = 0;
        for (int rowPos = maxRow; rowPos > maxRow - this.height; rowPos--) {
            terminalFrame.setCursorPosition(this.position, rowPos);
            terminalFrame.putCharacter(count == (this.height / 2) ? (char) ('0' + this.height) : ' ');
            count++;
        }

    }

}
