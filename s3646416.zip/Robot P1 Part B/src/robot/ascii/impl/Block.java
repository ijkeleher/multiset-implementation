package robot.ascii.impl;

import com.googlecode.lanterna.TextColor;
import com.googlecode.lanterna.terminal.swing.SwingTerminalFrame;
import control.Control;

public class Block extends AbstractItem implements Drawable {
    // the x axis here is the horizontal position of the block
    // the y (vertical) axis is represented by the position variable
    private int xAxis = 0;

    public Block(int height, int position, int xAxis) {
        super(height, position);
        this.xAxis = xAxis;
    }

    @Override
    public void draw(SwingTerminalFrame terminalFrame) {
        int maxRow = terminalFrame.getTerminalSize().getRows() - 1;
        int maxCol = terminalFrame.getTerminalSize().getColumns() - 1;

        // set colours depending on height of blocks
        if (super.getHeight() == 1)
            terminalFrame.setBackgroundColor(TextColor.ANSI.YELLOW);
        else if (super.getHeight() == 2)
            terminalFrame.setBackgroundColor(TextColor.ANSI.RED);
        else if (super.getHeight() == 3)
            terminalFrame.setBackgroundColor(TextColor.ANSI.BLUE);

        // draw a 'bar' of height "draw_height" in middle column
        // NOTE: we translate to terminal co-ordinates where 0,0 is top left!

        for (int rowPos = 0; rowPos < super.getHeight(); rowPos++) {
            terminalFrame.setCursorPosition(this.xAxis, super.getPosition() - rowPos);
            terminalFrame.putCharacter(' ');
        }
    }

    public void setXAxis(int xAxis) {
        this.xAxis = xAxis;
    }

    public int getXAxis() {
        return xAxis;
    }

}
