package robot.ascii;

import com.googlecode.lanterna.TextColor;
import robot.ascii.impl.*;
import control.Control;
import control.RobotControl;
import robot.Robot;
import robot.RobotMovement;
import robot.impl.RobotImpl;
import robot.impl.RobotInitException;

// ASCIIBot template code Programming 1 s2, 2017
// designed by Caspar, additional code by Ross
public class ASCIIBot extends AbstractASCIIBot implements Robot {

    private AbstractItem[] bars;
    private AbstractItem[] blocks;
    private Arm arm;
    int srcHt1 = 0;
    int srcHt2 = 0;
    private int blockCount;
    int blockCounter;

    public static void main(String[] args) {
        new RobotControl().control(new ASCIIBot(), null, null);
    }

    // MUST CALL DEFAULT SUPERCLASS CONSTRUCTOR!
    public ASCIIBot() {
        super();
    }

    @Override
    public void init(int[] barHeights, int[] blockHeights, int height, int width, int depth) {
        // in addition to validating init params this also sets up keyboard
        // support for the ASCIIBot!
        try {
            RobotImpl.validateInitParams(this, barHeights, blockHeights, height, width, depth);
        } catch (RobotInitException e) {
            System.err.println(e.getMessage());
            System.exit(0);
        }

        System.out.print(terminalFrame.getTerminalSize().getColumns() - 1);
        System.out.print(terminalFrame.getTerminalSize().getRows() - 1);

        // set size of bars array from barHeights
        this.bars = new AbstractItem[barHeights.length];

        // cycle through barheights array to fill bars array
        // bar positions set at index +2
        for (int i = 0; i < barHeights.length; i++) {
            bars[i] = new Bar(barHeights[i], i + 2);
        }

        // set size of blocks array from blockHeights
        this.blocks = new AbstractItem[blockHeights.length];

        // source heights are incremented by block size (alternating each time!)
        for (int i = 0; i < blockHeights.length; i++) {
            if (i % 2 == 0) {
                blocks[i] = new Block(blockHeights[i], (12 - srcHt1), Control.SRC1_COLUMN);
                srcHt1 += blockHeights[i];
                blockCount++;
            } else {
                blocks[i] = new Block(blockHeights[i], (12 - srcHt2), Control.SRC2_COLUMN);
                srcHt2 += blockHeights[i];
                blockCount++;
            }

        }

        // initialise arm
        this.arm = new Arm(height, width, depth, null);

        // draw the asciibot program!
        draw(bars, blocks, arm);

        // this is the blockCounter which keeps track of which block we're
        // moving
        blockCounter = blocks.length - blockCount;

    }

    // this methid updates the x and y axis of the block for the block
    private void updateBlockPosition() {
        if (arm.getBlock() != null) {
            ((Block) this.blocks[blockCount]).setPosition(arm.getDepth() + this.blocks[blockCount].getHeight());
            ((Block) this.blocks[blockCount]).setXAxis(arm.getWidth());
        }
    }

    private void draw(AbstractItem[] bars, AbstractItem[] blocks, Arm arm) {

        delayAnimation();

        for (AbstractItem Bar : bars) {
            Bar.draw(terminalFrame);
        }

        for (AbstractItem Block : blocks) {
            Block.draw(terminalFrame);
        }

        arm.draw(terminalFrame);

        terminalFrame.flush();

    }

    @Override
    public void pick() {
        // implement methods to draw robot environment using your implementation
        // of Arm.draw(), Bar.draw() etc.
        System.out.println("pick()");
        arm.pick();
        arm.setBlock(blocks[blockCount]);
        blockCount--;
        draw(bars, blocks, arm);
        System.out.println(arm.getBlock());
    }

    @Override
    public void drop() {
        System.out.println("drop()");
        arm.drop();
        arm.setBlock(null);
        draw(bars, blocks, arm);
    }

    @Override
    public void up() {
        System.out.println("up()");
        arm.up();
        updateBlockPosition();
        draw(bars, blocks, arm);
    }

    @Override
    public void down() {
        System.out.println("down()");
        arm.down();
        updateBlockPosition();
        draw(bars, blocks, arm);
    }

    @Override
    public void contract() {
        System.out.println("contract()");
        arm.contract();
        updateBlockPosition();
        draw(bars, blocks, arm);
    }

    @Override
    public void extend() {
        System.out.println("extend()");
        arm.extend();
        updateBlockPosition();
        draw(bars, blocks, arm);

    }

    @Override
    public void lower() {
        System.out.println("lower()");
        arm.lower();
        updateBlockPosition();
        draw(bars, blocks, arm);
    }

    @Override
    public void raise() {
        System.out.println("raise()");
        arm.raise();
        updateBlockPosition();
        draw(bars, blocks, arm);
    }
}
